# Marks workers as a Python package.
